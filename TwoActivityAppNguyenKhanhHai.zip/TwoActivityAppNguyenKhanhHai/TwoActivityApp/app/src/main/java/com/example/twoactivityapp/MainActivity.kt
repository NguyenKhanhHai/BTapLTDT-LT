package com.example.twoactivityapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnGoToDetail: Button = findViewById(R.id.btnGoToDetail)
        btnGoToDetail.setOnClickListener {
            val intent = Intent(this, DetailActivity::class.java)
            // Có thể truyền dữ liệu kèm theo nếu muốn:
            // intent.putExtra("message", "Xin chào từ Main!")
            startActivity(intent)
        }
    }
}
